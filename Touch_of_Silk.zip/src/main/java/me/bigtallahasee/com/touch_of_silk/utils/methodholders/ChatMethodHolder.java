package me.bigtallahasee.com.touch_of_silk.utils.methodholders;

import me.bigtallahasee.com.touch_of_silk.Touch_Of_Silk;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class ChatMethodHolder {
    /*Player player;
    Plugin plugin = Touch_Of_Silk.getPlugin(Touch_Of_Silk.class);

    //Variables for Creator and contributors
    String creator = "BigTallahasee";
    String contributors = "";
    String version = "1.0";

    ChatMethodHolder(){

    }

    public void onReload(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"We have spotted a reload!");
        player.sendMessage("");
        player.sendMessage(ChatColor.RED +"This is not recommended!");
        player.sendMessage("");
        player.sendMessage(ChatColor.RED +"If reloading this plugin causes any issues please attempt");
        player.sendMessage(ChatColor.RED +"restarting the server to fix the issue!");
        player.sendMessage("");
        player.sendMessage(ChatColor.RED +"If you are still in need of assistance do /support to ");
        player.sendMessage(ChatColor.RED +"retrieve our Github and Discord!");
    }

    public void doneReload(){
        player.sendMessage(ChatColor.GREEN +"Touch of Silk has finished reloading!");
    }

    public void disableAmethyst(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"You have disabled players from");
        player.sendMessage(ChatColor.RED +"silk touching Budding Amethyst!");
    }
    public void disableSpawners(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"You have disabled players from");
        player.sendMessage(ChatColor.RED +"silk touching Spawners!");
    }
    public void enableAmethyst(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"You have enabled silk touching Budding Amethyst");
    }
    public void enableSpawners(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"You have enabled silk touching Spawners");
    }
    public void onSupportCommand(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"We do apologize that you are having issues!");
        player.sendMessage("");
        player.sendMessage(ChatColor.RED +"You can reach out to us on our Discord and Github!");
        player.sendMessage(ChatColor.RED +"Discord : https://discord.gg/c9zCA4P");
        player.sendMessage(ChatColor.RED +"Github : https://github.com/Galaxy-Indie-Studio/Touch_Of_Silk");
    }
    public void noPermission(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"You don't have the proper permission to");
        player.sendMessage(ChatColor.RED +"execute this command!");
        player.sendMessage(ChatColor.RED +"Required permission (tos.admin/tos.*)");
    }
    public void onStatusCommand(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.GREEN +"Silk Touching Spawners Enabled: " +plugin.getConfig().get("Silk-Touch-Spawners-Enabled"));
        player.sendMessage(ChatColor.GREEN +"Silk Touching Budding Amethyst Enabled: " +plugin.getConfig().get("Silk-Touch-Budding-Amethyst-Enabled"));
    }

    public void onInfoCommand(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.GREEN +"This plugin was created by: " +creator);
        player.sendMessage( ChatColor.GREEN +"Contributors: " + contributors.toString());
        player.sendMessage(ChatColor.GREEN +"Current Plugin version: " +version);
    }

    public void noPermissions(){
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"| Touch of Silk |");
        player.sendMessage(ChatColor.LIGHT_PURPLE +"-----------------");
        player.sendMessage(ChatColor.RED +"You don't have the proper permission to");
        player.sendMessage(ChatColor.RED +"execute this command!");
        player.sendMessage(ChatColor.RED +"Required permission (tos.admin/tos.*)");
    }*/
}

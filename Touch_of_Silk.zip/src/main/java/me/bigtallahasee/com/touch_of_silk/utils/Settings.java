package me.bigtallahasee.com.touch_of_silk.utils;

public class Settings {

    public static String PLUGIN_URL = "https://spigotmc.org/resources/";
    public static String VERSION = "1.0";
}
